import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper=false)
@ToString(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter

public class Pais {
    private Long id;
    private String nombre;
    @Builder.Default
    private Set<Provincia> provincias = new HashSet<>();
}
