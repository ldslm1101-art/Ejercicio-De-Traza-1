import lombok.*;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter

class Localidad {
    @EqualsAndHashCode.Include
    private Long id;
    private String nombre;
    private Provincia provincia;
    private Domicilio domicilio;
}