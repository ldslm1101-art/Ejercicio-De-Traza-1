import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper=false)
@ToString(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter

class Main {
    public static void main(String[] args) {
        //Tenemos que crear un pais
        Pais argentina = new Pais(123L, "Argentina", new HashSet<>());
        //Creamos las respectivas provincias pertenecientes a este pais
        Provincia BSAS = new Provincia(1L, "Buenos Aires", argentina, new HashSet<>());
        Provincia Cordoba = new Provincia(2L, "Cordoba", argentina, new HashSet<>());
        argentina.getProvincias().add(BSAS);
        argentina.getProvincias().add(Cordoba);
        //Ahora creamos localidades y domicilios de Buenos Aires
        Localidad CABA = new Localidad(12L, "CABA", BSAS, new Domicilio(14L, "Av. 25 de Mayo", null));
        Localidad LaPlata = new Localidad(13L, "LaPlata", BSAS, new Domicilio(15L, "San Justo", null));
        Localidad CordobaCap = new Localidad(11L, "Cordoba Capital", Cordoba, new Domicilio(16L, "J.D. Peron", null ));
        Localidad RioCuarto = new Localidad(10L, "Rio Cuarto", Cordoba, new Domicilio(18L, "Av. Gral. San Martin", null));
        //Creamos las sucursales
        Sucursal s1 = new Sucursal(1L, "Sucursal 1", CABA.getDomicilio());
        Sucursal s2 = new Sucursal(2L, "Sucursal 2", LaPlata.getDomicilio());
        Sucursal s3 = new Sucursal(3L, "Sucursal 3", CordobaCap.getDomicilio());
        Sucursal s4 = new Sucursal(4L, "Sucursal 4", RioCuarto.getDomicilio());
        //Vamos a crear la empresa ahora
        Empresa e1 = new Empresa(3L, "SancorSeguros", "20-12345678-1", new HashSet<>());
        e1.agregarSucursal(s1);
        e1.agregarSucursal(s2);
        Empresa e2 = new Empresa(4L, "La Serenisima", "30-91011121-3", new HashSet<>());
        e2.agregarSucursal(s3);
        e2.agregarSucursal(s4);
        //Por ultimo vamos a mostrar todas nuestras empresas
        System.out.println("----------------TODAS LAS EMPRESAS-------------------");
        System.out.println(e1);
        System.out.println(e2);
        System.out.println("----------------SUS ID---------------");
        //Buscamos por ID
        if (e1.getId().equals(3L)){
            System.out.println("La empresa con este id es: " + e1);
        }
        //Buscamos por nombre
        System.out.println("---------------BUSCAMOS EL NOMBRE---------------");
        if ("Empresa 2".equals(e2.getNombre())) {
            System.out.println("El nombre de la segunda empresa es: " + e2);
        }
        //Actualizamos el CUIL
        System.out.println("---------------ACTUALIZAR LOS CUIL---------------");
        e1.setCuil("20-11111111-0");
        System.out.println();
        System.out.println("--------------ELIMINAR EMPRESA--------------");
        //Ahora vamos a eliminar una empresa
        e2=null;
        System.out.println("La empresa La Serenisima ha sido eliminada");
    }
}