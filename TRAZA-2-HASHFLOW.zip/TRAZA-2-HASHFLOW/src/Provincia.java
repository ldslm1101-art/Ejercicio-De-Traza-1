import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper=false)
@ToString(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter

public class Provincia {
    private Long id;
    private String nombre;
    private Pais pais;
    @Builder.Default
    private Set<Localidad> localidades = new HashSet<>();
}
