import lombok.*;

@Data
@EqualsAndHashCode(callSuper=false)
@ToString(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter

public class Domicilio {
    @EqualsAndHashCode.Include
    private Long id;
    private String direccion;
    private Localidad localidad;
}
