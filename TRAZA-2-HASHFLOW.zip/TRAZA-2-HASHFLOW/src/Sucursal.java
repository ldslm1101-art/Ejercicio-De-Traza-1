import lombok.*;

@Data
@EqualsAndHashCode(callSuper=false)
@ToString(callSuper=false)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter

class Sucursal {
    @EqualsAndHashCode.Include
    private Long id;
    private String nombre;
    private Domicilio domicilio;
}